Listing 16 is the last jQuery example in the text and is included to provide a starting point for all of the other examples. Any of the jQuery examples can be created by simply substituting the script code in the text into the Default.js script file.

To load the program, unzip the file and then open the .vbproj file in Visual Studio Express for Web 2012.