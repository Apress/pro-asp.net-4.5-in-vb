﻿Imports System.Collections.Generic
Public Class ResponseRepository
    Private Shared repository As New ResponseRepository()
    Private responses As New List(Of GuestResponse)()

    Public Shared Function GetRepository() As ResponseRepository
        Return repository
    End Function

    Public Function GetAllResponses() As IEnumerable(Of GuestResponse)
        Return responses
    End Function

    Public Sub AddResponse(response As GuestResponse)
        responses.Add(response)
    End Sub
End Class

