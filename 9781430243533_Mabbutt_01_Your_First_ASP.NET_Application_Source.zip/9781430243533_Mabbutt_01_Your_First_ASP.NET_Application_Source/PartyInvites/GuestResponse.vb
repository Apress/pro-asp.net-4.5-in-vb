﻿Imports System.ComponentModel.DataAnnotations

Public Class GuestResponse
    <Required> _
    Public Property Name() As String
    <Required> _
    Public Property Email() As String
    <Required> _
    Public Property Phone() As String
    <Required(ErrorMessage:="Please tell us if you will attend")>
    Public Property WillAttend() As Nullable(Of Boolean)
End Class

