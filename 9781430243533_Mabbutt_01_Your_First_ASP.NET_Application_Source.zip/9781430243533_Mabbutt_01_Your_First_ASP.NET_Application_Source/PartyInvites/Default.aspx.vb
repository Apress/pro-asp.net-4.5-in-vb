﻿Imports System.Web.ModelBinding
Public Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(
        ByVal sender As Object, ByVal e As System.EventArgs
        ) Handles Me.Load
        If IsPostBack Then
            Dim rsvp As New GuestResponse()
            If TryUpdateModel(
                rsvp,
                New FormValueProvider(ModelBindingExecutionContext)
                ) Then
                ResponseRepository.GetRepository().AddResponse(rsvp)
                If rsvp.WillAttend.HasValue And rsvp.WillAttend.Value Then
                    Response.Redirect("seeyouthere.html")
                Else
                    Response.Redirect("sorryyoucantcome.html")
                End If
            End If
        End If
    End Sub
End Class
