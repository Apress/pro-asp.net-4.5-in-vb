﻿Public Class Summary
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Function GetNoShowHtml() As String
        Dim html As New StringBuilder()
        Dim noData = ResponseRepository.GetRepository().GetAllResponses().
            Where(Function(r) r.WillAttend.HasValue AndAlso Not r.WillAttend.Value)
        For Each rsvp In noData
            html.Append([String].Format(
            "<tr><td>{0}</td><td>{1}</td><td>{2}</td>",
            rsvp.Name, rsvp.Email, rsvp.Phone))
        Next
        Return html.ToString()
    End Function

End Class